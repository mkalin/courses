#define BUFF_SIZE (1024)   /* for client read/write */
#define BACKLOG     (12)   /* maximum number of concurrent clients */
enum {false, true};        /* 0 and 1, respectively */
typedef unsigned bool;     /* bool aliases unsigned int */
